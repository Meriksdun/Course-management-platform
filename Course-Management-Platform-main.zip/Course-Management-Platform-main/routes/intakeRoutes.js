/**
 * @swagger
 * /cohorts:
 *   post:
 *     summary: Create a cohort and intake
 *     tags: [Cohorts]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               intake:
 *                 type: string
 *     responses:
 *       201:
 *         description: Cohort created
 */


const express = require('express');
const router = express.Router();
const intakeController = require('../controllers/intakeController');

router.get('/', intakeController.getAllIntakes);

module.exports = router;
